package org.example.planitfitness;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlanitFitnessApplicationTests {

    @Test
    void contextLoads() {
    }

}
